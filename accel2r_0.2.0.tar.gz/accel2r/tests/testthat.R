library(testthat)
library(accel2r)

test_check("accel2r")
