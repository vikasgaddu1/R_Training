## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(accel2r)

## -----------------------------------------------------------------------------
a2r_compare_data(mtcars, mtcars[1:3])

## ---- eval=FALSE--------------------------------------------------------------
#  a2r_validate_capstone()

