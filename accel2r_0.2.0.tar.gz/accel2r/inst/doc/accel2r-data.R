## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(accel2r)
requireNamespace("fs", quietly = TRUE)
requireNamespace("tidyr", quietly = TRUE)
requireNamespace("knitr", quietly = TRUE)

## ---- echo = FALSE, cache=TRUE------------------------------------------------
path <- if (interactive()) "./data" else "../data"

path %>%
  fs::dir_info() %>%
  dplyr::transmute(path = fs::path_file(path) %>% fs::path_ext_remove()) %>%
  tidyr::separate(path, into = c("df_type", "course", "lesson", "df_name"), remove = F, sep = "_") %>%
  dplyr::mutate(
    dplyr::across(c(lesson), stringr::str_to_title),
    df_type = dplyr::case_when(
      df_type == "sd" ~ "Solution Data"),
    course = dplyr::case_when(
      course == "rlanguage1"   ~ "R Language Foundations 1",
      course == "rlanguage2"   ~ "R Language Foundations 2",
      course == "tidyverse"    ~ "Tidyverse Data Manipulation",
      course == "supplemental" ~ "Supplemental Tools/Packages"
    )
  ) %>%
  knitr::kable()

