
<!-- README.md is generated from README.Rmd. Please edit that file -->

# Welcome to the Accel2R Package

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![CRAN
status](https://www.r-pkg.org/badges/version/accel2r)](https://CRAN.R-project.org/package=accel2r)
<!-- badges: end -->

The goal of the Accel2R package is to provide functions that will assist
you as you progress through the Accel2R curriculum.

## Installation

Check the resources area of the Accel2R website for the most recent
version of this pacakge. Once you have the `tar.gz` package file saved
locally, you can install the package with the following command:

``` r
# Install the 'remotes' package from CRAN
install.packages("remotes")

# Then use 'remotes' to install a local package
remotes::install_local("path/to/tar.gz")
```

## Loading the Package

``` r
library(accel2r)
#> | Welcome to the accel2r package! (v.0.1.0)
#> | - Please ensure you are using to most recent version of this package.
#> | - See the help and vignette pages for instructions on how to use the provided functions and data:
#> 
#> help(a2r_validate_data)
#> help(a2r_validate_capstone)
#> 
#> vignette('howto-exercise-validation')
#> vignette('accel2r-data')
```

## Readme - To Do

You’ll still need to render `README.Rmd` regularly, to keep `README.md`
up-to-date. `devtools::build_readme()` is handy for this. You could also
use GitHub Actions to re-render `README.Rmd` every time you push. An
example workflow can be found here:
<https://github.com/r-lib/actions/tree/v1/examples>.
