
#' @title Compare Two Data Frames
#'
#' @description `a2r_compare_data` makes use of the [`arsenal::comparedf()`]
#'   function to provide a detailed description of the differences between two
#'   data frames.
#'
#'   See the `vignette('howto-exercise-coach')` for more information on how this
#'   function can be used to assist you as you work through the exercises within
#'   the Accel2R curriculum
#'
#' @section Arsenal Compare Function:
#'
#'   See [`arsenal::comparedf()`] for a more detailed explanation of how to
#'   customize this function for your own use cases.
#'
#' @param df_1 The first dataframe to compare
#' @param df_2 The second dataframe to compare
#' @return A console message displaying the differences between the two given
#'   data frames
#'
#' @export
#'
#' @examples
#' \dontrun{
#' a2r_compare_data(mtcars, mtcars[c("mpg", "am")])
#' }
#'
a2r_compare_data <- function(df_1, df_2){
  summary(arsenal::comparedf(df_1, df_2))
}


# Capstone Coach ----------------------------------------------------------

#' @title Accel2R Capstone Coach
#'
#' @description This is a function that helps you check your progress throughout
#' the capstone exercises for the three courses:
#'
#' * R Language Foundations 1
#' * R Language Foundations 2
#' * Tidyverse Data Manipulation
#'
#' **Note**: This function will scan your working environment.  It is **important**
#' that your dataframe names and variable names exactly match those that are listed
#' in the exercise document, otherwise this validation function will not work as
#' expected
#'
#' @return Console messages checking the steps of your progress through the
#'   capstones
#'
#' @export
#'
a2r_capstone_coach <- function(){

  .av_message("Welcome to the Accel2R Capstone Coach")
  .av_message("Please choose the capstone that you are currently working on.")

  .selection <-
    utils::menu(c(
      "Exit Selection",
      "R Language Foundations 1",
      "R Language Foundations 2",
      "Tidyverse Data Manipulation"
    ))

  if (.selection == 2){
    .av_capstone_2()
  } else if (.selection == 3){
    .av_capstone_3()
  } else if (.selection == 4){
    .av_capstone_4()
  }

}


# -------------------------------------------------------------------------

.onAttach <- function(libname, pkgname){
  packageStartupMessage(
    "| Welcome to the Accel2R package! (v.", utils::packageVersion(pkgname),")\n",
    "| - Please ensure you are using to most recent version of this package.\n",
    "| - See the help and vignette pages for instructions on how to use the provided functions and data:\n",
    "\n",
    "help(a2r_compare_data)\n",
    "help(a2r_capstone_coach)\n",
    "\n",
    "vignette('accel2r-data')",
    "vignette('howto-exercise-coach')\n",
    "\n"
  )
}
