
# Capstone 2 -------------------------------------------------------------

.av_capstone_2 <- function(){
  .av_message_welcome("R Language Foundations 1")
  .env <- ls(all.names = T, name = globalenv())

  .av_message("This Exercise Coach function will provide a detailed comparison of the solution data with your data.")
  .av_message("This will make use of the `arsenal` package.")
  .av_message("See `help(comparedf, package = 'arsenal')` for more information")
  .av_message()

  Sys.sleep(1)

  if ("demog" %in% .env){
    a2r_compare_data(demog, sd_rlanguage1_capstone_demo)
  } else {
    .av_message_data("demog", F)
  }

}

# Capstone 3 -------------------------------------------------------------

.av_capstone_3 <- function(){

  .av_message_welcome("R Language Foundations 2")
  .env <- ls(all.names = T, name = globalenv())

  # Validation Steps
  .chk_data <- "df" %in% .env
  if (.chk_data){

    .av_message_data("df")

    # Data Checks
    .chk_dims <- all(dim(df) == c(85, 6))
    .chk_vars <- all(c("ReportARM", "agec") %in% colnames(df))
    .chk_vals <- (all(table(df$ReportARM) == c(65, 20))) & (all(table(df$agec) == c(0, 5, 23, 35, 22)))

    # Validation Messages
    if (.chk_dims){
      .av_message("You have the correct number of rows and columns in the data.")

      if (.chk_vars){
        .av_message_colnames(T)
      } else {
        .av_message_colnames(F)
      }

      if (.chk_vals){
        .av_message_newvar("ReportARM, agec", T)
      } else {
        .av_message_newvar("ReportARM, agec", F)
      }

    } else {
      .av_message("You do not have the correct number of rows and columns in the data.")
    }


  } else {
    .av_message_data("df", F)
  }

  .av_message()
  Sys.sleep(1)

  .chk_final <- "demog" %in% .env
  if (.chk_final & .chk_data){
    .av_message_data("demog", T)

    # Data Checks
    .chk_f_dms <- all(dim(demog) == c(15, 4))
    .chk_f_nms <- all(c("stub", "labels", "stats_active", "stats_placebo") %in% colnames(demog))
    .chk_f_atr <- all(
      unlist(lapply(demog, attributes)) == c("Measure", "Statistic", "Active (N=65)", "Placebo (N=20)"),
      !is.null(unlist(lapply(demog, attributes)))
    )

    # Validation Messages
    if (.chk_f_dms){
      .av_message("You have the correct number of rows and columns in the data.")

      if (.chk_f_nms){
        .av_message_colnames(T)

        if (.chk_f_atr){
          .av_message("You have correctly specified the attributes on the variables.")

          .av_message()
          .av_message("---")
          .av_message("")
          .av_message("We can provide a detailed comparison of these dataframes.")
          .av_message("Which dataframe would you like to compare?")

          .df_compare <- utils::menu(c("none", "df", "demog"))

          if (.df_compare == 3){
            a2r_compare_data(demog, sd_rlanguage2_capstone_demo)
          } else if (.df_compare == 2) {
            a2r_compare_data(df, sd_rlanguage2_capstone_df)
          }
        } else {
          .av_message("You have not properly specified the attributes on the variables.")
        }
      } else {
        .av_message_colnames(F)
      }
    } else {
      .av_message("You do not have the correct number of rows and columns in the data.")
      .av_message_fail()
    }
  } else {
    .av_message_data("demog", F)
  }
}

# Capstone 4 --------------------------------------------------------------

.av_capstone_4 <- function(){

  .av_message_welcome("Tidyverse Data Manipulation")
  .env <- ls(all.names = T, name = globalenv())


  # Check for Data
  .chk_demo <- "data_demo" %in% .env

  if (.chk_demo){

    .av_message_data("data_demo")

    # Check for New Factor
    .chk_factor <-
      data_demo %>%
      purrr::map(~ class(.) %>% stringr::str_detect("factor")) %>%
      purrr::flatten_lgl() %>%
      any()

    if (.chk_factor){
      .av_message("You have correctly created a new factor variable for the new category")
    } else {
      .av_message("You have not created a new factor variable for the new race category.")
      .av_message_fail()
    }

    # Check for New Count
    .chk_count_1 <- "categorical_race_total" %in% .env
    if (.chk_count_1){
      .chk_count_2 <- nrow(categorical_race_total) == 5
      if (.chk_count_2){
        .av_message("You have properly defined the new factor levels.")
      } else {
        .av_message("You have not properly defined the new factor levels.")
        .av_message_fail()
      }
    }

    # Check Final E1 Data
    .chk_final <- "complete_summary" %in% .env

    if (.chk_final){
      .av_message("We can now compare your `complete_summary` with the solution data.")
      .av_message("Would you like to continue?")
      .waldo_compare <- utils::menu("Yes", "No")

      if (.waldo_compare == 1){
        a2r_compare_data(complete_summary, sd_tidyverse_capstone_E1)
      }

    } else {
      .av_message_data("complete_summary", F)
      .av_message_fail()
    }

  } else {

    .av_message_data("data_demo", F)

  }


  # Exercise 2
  .av_message()
  .av_message("For exercise 2 of this capstone, you will have to use the `a2r_compare_data` function from the `accel2r` package.")
  .av_message("Run help('a2r_compare_data', package = 'accel2r') to see how to use this function")
  .av_message("")
  .av_message("The solution dataset you want to use for comparison is `sd_tidyverse_capstone_E2`")
}
