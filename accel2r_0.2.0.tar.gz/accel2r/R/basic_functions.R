
# -------------------------------------------------------------------------

.av_message <- function(text = ""){
  message(sprintf("| %s", text))
}

# -------------------------------------------------------------------------

.av_message_fail <- function(){
  .av_message("Correct the issue and try again.")
}

# -------------------------------------------------------------------------

.av_message_welcome <- function(title){
  sprintf("Welcome to '%s'", title) |> .av_message()
  .av_message("Let's check your progress on this exercise.")
  .av_message("This function will scan your Global Environment...")
  .av_message()
  Sys.sleep(1)
}

# -------------------------------------------------------------------------

.av_message_data <- function(data, success = T){
  if (success){
    .av_message(
      sprintf("Looks like you correctly created the dataframe '%s'.", data)
    )
  } else {
      .av_message(
        sprintf("Looks like you do not have a dataframe named '%s'.", data)
      )
    .av_message_fail()
  }
}

# -------------------------------------------------------------------------

.av_message_colnames <- function(success = T){
  if (success){
    .av_message("You have correctly specified the variables to include in the data")
  } else{
    .av_message("You have not correctly specified the variables to include in the data.")
    .av_message_fail()
  }
}

# -------------------------------------------------------------------------

.av_message_rows <- function(success = T){
  if (success){
    .av_message("You have correctly filtered the rows to include in the data")
  } else {
    .av_message("You have not correctly specified the rows to include in the data.")
    .av_message_fail()
  }
}

# -------------------------------------------------------------------------

.av_message_newvar <- function(varname, success = T){
  if (success){
    .av_message(
      sprintf("You have correctly created the new variable '%s'.", varname))
  } else {
    .av_message(
      sprintf("You have not correctly created the new variable '%s'.", varname))
    .av_message_fail()
  }
}

# -------------------------------------------------------------------------

.convert_rds_to_rda <- function(inpath = "../data", outpath = "data"){

  i <- fs::dir_map(inpath, readRDS, type = "file")
  n <- fs::dir_ls(inpath) %>% fs::path_file() %>% fs::path_ext_remove()

  walk2(i, n, function(obj, name){
    assign(name, obj)
    do.call(usethis::use_data, list(as.name(name), overwrite = T))
  })
}

# .convert_rds_to_rda()

# -------------------------------------------------------------------------

# This is used for the vignette/help listings
.get_data_listing <- function(inpath = "data"){
  fs::dir_ls(inpath) %>%
    fs::path_ext_remove() %>%
    path_file() %>%
    dput()
}
