# accel2r 0.2.0

* Adding packages that default Accel2R curriculum depends on

# accel2r 0.1.0

* Added help pages for the two initial functions, a2r_compare_data and a2r_validate_capstone
* Added vignettes 'howto-exercise-validation' and 'accel2r-data'
* Added data to the package for use by the users of the package

# accel2r 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
* Initial creation of the package
